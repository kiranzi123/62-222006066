 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
 	<title>welcome</title>
 </head>
 <body>
 	<form method="post"action="insert.php">
 		<center>
 		Firstname:<input type="text" name="fn"><br><br>
 		lastname:<input type="text" name="ln"><br><br>
 		gender:<input type="radio" name="gender"value="male">Male <nbsp><input type="radio" name="gender"value="female">Female <br>
 		<select name="cs">
 			<option>select course</option>
 			<option>bit</option>
 			<option>HRM</option>
 			<option>Finance</option>
 		option>banking</option>
 			<option>tv show and film production</option>
 		</select>
 		<input type="submit" name="send"value="insert">
 		</center>
 	</form>
 
 </body>
 </html>