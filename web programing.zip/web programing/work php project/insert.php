<?php
$con=mysqli_connect('localhost','root','','bit2024');
if(isset($_POST['send'])){
	$fn=$_POST['fn'];
	$ln=$_POST['ln'];
	$gender=$_POST['gender'];
	$cs=$_POST['cs'];
	$sql="INSERT INTO mytable(id,firstname,lastname,gender,course) values(null,'$fn','$ln','$gender','$cs')";
	 // to insert data into database
	if (mysqli_query($con,$sql)==true) {
		echo'inserted successful';
		// display information of table when inserted
	echo"<table border='1'>
	<tr><th>id</th><th>firstname</th><th>lastname</th><th>gender</th><th>course</th><tr>";
	$select="select * from mytable";
	$query2=mysqli_query($con,$select);
	if($query2==true){
		while ($r=mysqli_fetch_array($query2)) {
    echo"<tr><td>";
	echo $r['id'];
	echo"</td><td>";
	echo $r['firstname'];
	echo"</td><td>";
	echo $r['lastname'];
	echo"</td><td>";
	echo $r['gender'];
	echo"</td><td>";
	echo $r['course'];
	echo"</td></tr>";
	}}
	else{
		echo'not selected';
	}
}
else{
	echo "not inserted well!!!!!!!!!!!!";
}
}
?>